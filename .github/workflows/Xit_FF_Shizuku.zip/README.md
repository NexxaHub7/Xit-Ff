# Xit FF

Panel flotante para Android con Shizuku.

Funciones:
- Ventana pequeña flotante.
- Atajo de cuatro dedos en menos de 5 segundos mediante AccessibilityService.
- `Xit FF`: aplica `wm size 1500x3500` y `wm density 510`.
- Reversión automática a los 5 segundos.
- Opción para aplicar sin revertir.
- Botón Restaurar.
- Toggle de optimización: desactiva animaciones del sistema mediante Shizuku. No fuerza frecuencias de CPU/GPU ni temperaturas peligrosas.

Requisitos:
- Android 7.0+.
- Permiso de ventana flotante.
- Servicio de accesibilidad activado.
- Shizuku iniciado y autorizado para Xit FF.
- Shizuku puede funcionar con ADB o root; el proyecto no requiere que el APK tenga root directo. La documentación oficial de Shizuku indica que la API puede operar con identidad ADB o root. 

Nota:
Cambiar `wm size`/`wm density` afecta al sistema completo, no únicamente a Free Fire. La opción de 5 segundos es la recomendada para probar. "Sin revertir" queda bajo responsabilidad del usuario; siempre existe el botón Restaurar.
