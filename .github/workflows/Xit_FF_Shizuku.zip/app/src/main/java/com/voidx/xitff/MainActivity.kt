package com.voidx.xitff

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import android.graphics.Color
import android.view.Gravity
import com.google.android.material.button.MaterialButton
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 30, 30, 30)
            setBackgroundColor(Color.rgb(14, 14, 18))
        }
        val title = TextView(this).apply {
            text = "Xit FF"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Panel flotante para resolución y rendimiento.\n\n"
            textSize = 16f
            setTextColor(Color.LTGRAY)
        }
        root.addView(title)
        root.addView(info, LinearLayout.LayoutParams(-1, 0, 1f))

        root.addView(button("⚡ Iniciar Xit FF") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
                return@button
            }
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Activa el servicio de accesibilidad de Xit FF. Luego usa 4 dedos durante menos de 5 segundos.", Toast.LENGTH_LONG).show()
        })
        root.addView(button("🧪 Probar ventana") { FloatingPanel.show(this) })
        root.addView(button("🛠️ Comprobar Shizuku") {
            val ok = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
            Toast.makeText(this, if (ok) "Shizuku conectado." else "Shizuku no está conectado.", Toast.LENGTH_LONG).show()
        })
        setContentView(root)
    }
    private fun button(t: String, action: () -> Unit) =
        MaterialButton(this).apply { text=t; isAllCaps=false; setOnClickListener { action() } }
}
