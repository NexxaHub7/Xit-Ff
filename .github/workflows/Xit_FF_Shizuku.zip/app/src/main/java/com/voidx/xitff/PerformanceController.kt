package com.voidx.xitff

import android.content.Context
import android.widget.Toast

object PerformanceController {
    private var enabled = false
    fun toggle(context: Context) {
        try {
            if (!enabled) {
                // Ajustes de interfaz de Android que reducen animaciones.
                // No fuerza clocks ni temperaturas peligrosas.
                ShizukuShell.exec("settings put global window_animation_scale 0")
                ShizukuShell.exec("settings put global transition_animation_scale 0")
                ShizukuShell.exec("settings put global animator_duration_scale 0")
                enabled = true
                Toast.makeText(context, "Optimización activada", Toast.LENGTH_SHORT).show()
            } else {
                ShizukuShell.exec("settings put global window_animation_scale 1")
                ShizukuShell.exec("settings put global transition_animation_scale 1")
                ShizukuShell.exec("settings put global animator_duration_scale 1")
                enabled = false
                Toast.makeText(context, "Optimización desactivada", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
