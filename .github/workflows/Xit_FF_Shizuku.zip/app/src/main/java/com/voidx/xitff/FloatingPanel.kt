package com.voidx.xitff

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.view.*
import android.widget.*
import kotlin.math.roundToInt

object FloatingPanel {
    private var window: View? = null
    private var params: WindowManager.LayoutParams? = null

    fun show(context: Context) {
        if (!SettingsCompat.canDraw(context)) {
            Toast.makeText(context, "Concede permiso de ventana flotante.", Toast.LENGTH_LONG).show()
            return
        }
        if (window != null) return
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val box = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 8, 10, 10)
            setBackgroundColor(Color.rgb(20, 20, 28))
        }
        val top = LinearLayout(context).apply {
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(context).apply {
            text = "Xit FF"
            setTextColor(Color.WHITE)
            textSize = 14f
        }
        val minus = TextView(context).apply {
            text = "−"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        top.addView(title, LinearLayout.LayoutParams(0, 42, 1f))
        top.addView(minus, LinearLayout.LayoutParams(42, 42))
        box.addView(top)

        val resolution = Button(context).apply {
            text = "Xit FF 1500×3500 / 510"
            setOnClickListener { DisplayController.apply(context, true) }
        }
        val permanent = Button(context).apply {
            text = "Aplicar sin revertir"
            setOnClickListener { DisplayController.apply(context, false) }
        }
        val restore = Button(context).apply {
            text = "Restaurar"
            setOnClickListener { DisplayController.restore(context) }
        }
        val perf = Switch(context).apply {
            text = "Optimización"
            setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, _ -> PerformanceController.toggle(context) }
        }
        box.addView(resolution)
        box.addView(permanent)
        box.addView(restore)
        box.addView(perf)

        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            290.dp(context), WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 10.dp(context); y = 100.dp(context)
        }

        minus.setOnClickListener {
            wm.removeView(box)
            window = null
            Bubble.show(context)
        }

        wm.addView(box, lp)
        window = box
        params = lp
    }

    fun hide(context: Context) {
        window?.let {
            (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it)
            window = null
        }
    }

    private fun Int.dp(c: Context): Int = (this * c.resources.displayMetrics.density).roundToInt()
}

object SettingsCompat {
    fun canDraw(c: Context) = android.provider.Settings.canDrawOverlays(c)
}

object Bubble {
    private var view: View? = null
    fun show(context: Context) {
        if (!SettingsCompat.canDraw(context) || view != null) return
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val b = TextView(context).apply {
            text = "X"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(55, 35, 90))
            setOnClickListener {
                wm.removeView(this)
                view = null
                FloatingPanel.show(context)
            }
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            48.dp(context), 48.dp(context), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x=10.dp(context); y=100.dp(context) }
        wm.addView(b, lp)
        view=b
    }
    private fun Int.dp(c: Context): Int = (this * c.resources.displayMetrics.density).roundToInt()
}
