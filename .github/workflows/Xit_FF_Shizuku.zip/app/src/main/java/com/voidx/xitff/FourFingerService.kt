package com.voidx.xitff

import android.accessibilityservice.AccessibilityService
import android.view.MotionEvent
import android.os.SystemClock

class FourFingerService : AccessibilityService() {
    private var firstFourAt = 0L
    private var triggered = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        // Service is only used for the global gesture shortcut.
    }

    override fun onMotionEvent(event: MotionEvent) {
        val now = SystemClock.uptimeMillis()
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                firstFourAt = now
                triggered = false
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (event.pointerCount >= 4 && now - firstFourAt <= 5000 && !triggered) {
                    triggered = true
                    FloatingPanel.show(this)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (now - firstFourAt > 5000) {
                    triggered = false
                }
            }
        }
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
