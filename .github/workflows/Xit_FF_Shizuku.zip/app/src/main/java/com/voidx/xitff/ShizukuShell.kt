package com.voidx.xitff

import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

object ShizukuShell {
    fun exec(command: String): String {
        if (!Shizuku.pingBinder()) throw IllegalStateException("Shizuku no está conectado")
        val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
        val out = BufferedReader(InputStreamReader(process.inputStream)).readText()
        process.waitFor()
        return out
    }
    fun get(command: String): String = exec(command).trim()
}
