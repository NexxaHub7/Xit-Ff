package com.voidx.xitff

import android.content.Context
import android.widget.Toast
import kotlinx.coroutines.*
import java.util.concurrent.atomic.AtomicBoolean

object DisplayController {
    private var originalSize: String? = null
    private var originalDensity: String? = null
    private val applied = AtomicBoolean(false)

    fun apply(context: Context, revertAfterFiveSeconds: Boolean) {
        try {
            if (originalSize == null) originalSize = ShizukuShell.get("wm size")
            if (originalDensity == null) originalDensity = ShizukuShell.get("wm density")

            ShizukuShell.exec("wm size 1500x3500")
            ShizukuShell.exec("wm density 510")
            applied.set(true)

            Toast.makeText(context, "Xit FF: 1500×3500 / DPI 510 aplicado", Toast.LENGTH_SHORT).show()

            if (revertAfterFiveSeconds) {
                CoroutineScope(Dispatchers.IO).launch {
                    delay(5000)
                    restore(context)
                }
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Error Shizuku: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    fun restore(context: Context) {
        try {
            val s = originalSize
            val d = originalDensity
            if (s != null) {
                val value = s.substringAfter("Physical size:", "").trim().ifBlank {
                    s.substringAfter("Override size:", "").trim()
                }
                if (value.isNotBlank()) ShizukuShell.exec("wm size reset")
            } else ShizukuShell.exec("wm size reset")

            if (d != null) ShizukuShell.exec("wm density reset")
            applied.set(false)
            Toast.makeText(context, "Resolución/DPI restaurados", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(context, "No se pudo restaurar: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
